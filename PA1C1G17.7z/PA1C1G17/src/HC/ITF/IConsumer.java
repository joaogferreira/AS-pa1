package HC.ITF;

import HC.ActiveEntities.TPatient;

public interface IConsumer {
    TPatient get();
}
