package HC.ITF;

import HC.ActiveEntities.TPatient;


public interface IProducer {
    void put(TPatient increment);
}
